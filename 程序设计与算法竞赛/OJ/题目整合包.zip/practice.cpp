#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <set>
#include <cmath>
#include <cstring>
using namespace std;
typedef long long ll;

map<ll, ll> fa;

ll H(int n)
{
    ll res = 0;
    for (int i = 1; i <= n;)
    {
        ll v = n / i;
        ll next = n / v + 1;
        res += v * (next - i);
        i = next;
    }
    return res;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        cout << H(n) << endl;
    }
    return 0;
}